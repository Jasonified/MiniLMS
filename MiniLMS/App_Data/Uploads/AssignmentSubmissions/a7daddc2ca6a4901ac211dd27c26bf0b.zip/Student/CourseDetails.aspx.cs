
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniLMS.Student
{
    public partial class CourseDetails : Page
    {
        private string ConnectionString
        {
            get
            {
                return ConfigurationManager
                    .ConnectionStrings["EMiniLMSConnection"]
                    .ConnectionString;
            }
        }

        private int StudentID
        {
            get
            {
                return Convert.ToInt32(Session["UserID"]);
            }
        }

        private DataTable lessons;
        private DataTable materials;

        // =========================================
        // PAGE LOAD
        // =========================================

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserID"] == null ||
                Convert.ToString(Session["Role"]) != "Student")
            {
                RedirectToLogin();
                return;
            }

            if (!LoadSidebarProfile())
                return;

            if (!IsPostBack)
                LoadPageData();
        }

        private void RedirectToLogin()
        {
            Response.Redirect("~/Account/Login.aspx", false);
            Context.ApplicationInstance.CompleteRequest();
        }

        // =========================================
        // STUDENT PROFILE
        // =========================================

        private bool LoadSidebarProfile()
        {
            imgSidebarProfile.Visible = false;
            phSidebarDefaultAvatar.Visible = true;

            const string query = @"
                SELECT
                    FirstName,
                    LastName,
                    ProfileImageUrl
                FROM dbo.EUsers
                WHERE UserID = @StudentID
                  AND Role = 'Student'
                  AND IsApproved = 1
                  AND IsActive = 1;
            ";

            using (SqlConnection con =
                new SqlConnection(ConnectionString))
            using (SqlCommand cmd =
                new SqlCommand(query, con))
            {
                cmd.Parameters.Add(
                    "@StudentID", SqlDbType.Int
                ).Value = StudentID;

                con.Open();

                using (SqlDataReader reader =
                    cmd.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        Session.Clear();
                        Session.Abandon();
                        RedirectToLogin();
                        return false;
                    }

                    string firstName =
                        Convert.ToString(reader["FirstName"]);

                    string lastName =
                        Convert.ToString(reader["LastName"]);

                    lblStudentName.Text =
                        (firstName + " " + lastName).Trim();

                    string imagePath =
                        Convert.ToString(reader["ProfileImageUrl"]);

                    bool validPath = Regex.IsMatch(
                        imagePath ?? "",
                        @"^~/Images/Profiles/[a-f0-9]{32}\.(jpg|png)$",
                        RegexOptions.IgnoreCase |
                        RegexOptions.CultureInvariant
                    );

                    if (validPath &&
                        File.Exists(Server.MapPath(imagePath)))
                    {
                        imgSidebarProfile.ImageUrl =
                            ResolveUrl(imagePath);

                        imgSidebarProfile.Visible = true;
                        phSidebarDefaultAvatar.Visible = false;
                    }
                }
            }

            return true;
        }

        // =========================================
        // HELPER: EXECUTE PARAMETERIZED QUERY
        // =========================================

        private DataTable GetCourseData(
            SqlConnection con,
            string query,
            int courseID)
        {
            DataTable table = new DataTable();

            using (SqlCommand cmd =
                new SqlCommand(query, con))
            {
                cmd.Parameters.Add(
                    "@StudentID", SqlDbType.Int
                ).Value = StudentID;

                cmd.Parameters.Add(
                    "@CourseID", SqlDbType.Int
                ).Value = courseID;

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }

        // =========================================
        // LOAD COURSE DETAILS
        // =========================================

        private void LoadPageData()
        {
            pnlCourse.Visible = false;

            int courseID;

            if (!int.TryParse(
                Request.QueryString["CourseID"],
                out courseID) || courseID <= 0)
            {
                ShowMessage("Invalid course selection.");
                return;
            }

            using (SqlConnection con =
                new SqlConnection(ConnectionString))
            {
                con.Open();

                // =================================
                // 1. COURSE INFORMATION
                // Existing view:
                // vw_StudentCourseDetails
                // =================================

                const string courseQuery = @"
                    SELECT
                        V.CourseTitle,
                        V.CourseDescription,
                        V.InstructorName

                    FROM dbo.vw_StudentCourseDetails AS V

                    INNER JOIN dbo.EUsers AS U
                        ON U.UserID = V.StudentID

                    WHERE V.StudentID = @StudentID
                      AND V.CourseID = @CourseID
                      AND U.Role = 'Student'
                      AND U.IsApproved = 1
                      AND U.IsActive = 1;
                ";

                DataTable course = GetCourseData(
                    con, courseQuery, courseID);

                if (course.Rows.Count == 0)
                {
                    ShowMessage(
                        "Course not found or not assigned to your account.");
                    return;
                }

                DataRow row = course.Rows[0];

                lblCourseTitle.Text =
                    Convert.ToString(row["CourseTitle"]);

                lblCourseDescription.Text =
                    Convert.ToString(row["CourseDescription"]);

                lblInstructor.Text =
                    Convert.ToString(row["InstructorName"]);

                // =================================
                // 2. MODULES
                // Existing view: vw_EModules
                // =================================

                const string modulesQuery = @"
                    SELECT
                        M.ModuleID,
                        M.ModuleTitle

                    FROM dbo.vw_EModules AS M

                    WHERE M.CourseID = @CourseID

                    ORDER BY M.ModuleOrder, M.ModuleID;
                ";

                DataTable modules = GetCourseData(
                    con, modulesQuery, courseID);

                // =================================
                // 3. LESSONS
                // Existing views:
                // vw_ELessons, vw_EModules
                // =================================

                const string lessonsQuery = @"
                    SELECT
                        L.ModuleID,
                        L.LessonID,
                        L.LessonTitle,
                        L.LessonDescription

                    FROM dbo.vw_ELessons AS L

                    INNER JOIN dbo.vw_EModules AS M
                        ON M.ModuleID = L.ModuleID

                    WHERE M.CourseID = @CourseID

                    ORDER BY
                        M.ModuleOrder,
                        L.LessonOrder,
                        L.LessonID;
                ";

                lessons = GetCourseData(
                    con, lessonsQuery, courseID);

                // =================================
                // 4. PDF LESSON MATERIALS
                // Table: ELessonMaterials
                //
                // Only PDF filenames are retrieved.
                // Actual downloads are authorized
                // separately in DownloadMaterial.
                // =================================

                const string materialsQuery = @"
                    SELECT
                        LM.MaterialID,
                        LM.LessonID,
                        LM.FileName

                    FROM dbo.ELessonMaterials AS LM

                    INNER JOIN dbo.ELessons AS L
                        ON L.LessonID = LM.LessonID

                    INNER JOIN dbo.EModules AS M
                        ON M.ModuleID = L.ModuleID

                    WHERE M.CourseID = @CourseID

                    ORDER BY LM.UploadedAt DESC;
                ";

                materials = GetCourseData(
                    con, materialsQuery, courseID);

                // =================================
                // 5. BIND MODULES AND LESSONS
                // =================================

                pnlCourse.Visible = true;

                rptModules.DataSource = modules;
                rptModules.DataBind();

                pnlNoModules.Visible =
                    modules.Rows.Count == 0;
            }
        }

        // =========================================
        // BIND LESSONS UNDER EACH MODULE
        // =========================================

        protected void rptModules_ItemDataBound(
            object sender,
            RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType != ListItemType.Item &&
                e.Item.ItemType != ListItemType.AlternatingItem)
                return;

            int moduleID = Convert.ToInt32(
                DataBinder.Eval(
                    e.Item.DataItem, "ModuleID")
            );

            DataRow[] rows = lessons.Select(
                "ModuleID = " + moduleID
            );

            Repeater rptLessons =
                e.Item.FindControl("rptLessons")
                as Repeater;

            Label lblNoLessons =
                e.Item.FindControl("lblNoLessons")
                as Label;

            if (rptLessons != null)
            {
                rptLessons.DataSource =
                    rows.Length > 0
                        ? rows.CopyToDataTable()
                        : null;

                rptLessons.DataBind();
            }

            if (lblNoLessons != null)
            {
                lblNoLessons.Visible =
                    rows.Length == 0;
            }
        }

        // =========================================
        // BIND PDF FILES UNDER EACH LESSON
        // =========================================

        protected void rptLessons_ItemDataBound(
            object sender,
            RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType != ListItemType.Item &&
                e.Item.ItemType != ListItemType.AlternatingItem)
                return;

            int lessonID = Convert.ToInt32(
                DataBinder.Eval(
                    e.Item.DataItem, "LessonID")
            );

            DataRow[] rows = materials.Select(
                "LessonID = " + lessonID
            );

            Repeater rptMaterials =
                e.Item.FindControl("rptMaterials")
                as Repeater;

            Label lblNoMaterials =
                e.Item.FindControl("lblNoMaterials")
                as Label;

            if (rptMaterials != null)
            {
                rptMaterials.DataSource =
                    rows.Length > 0
                        ? rows.CopyToDataTable()
                        : null;

                rptMaterials.DataBind();
            }

            if (lblNoMaterials != null)
            {
                lblNoMaterials.Visible =
                    rows.Length == 0;
            }
        }

        // =========================================
        // MESSAGE
        // =========================================

        private void ShowMessage(string message)
        {
            lblMessage.Text = message;
            lblMessage.Visible = true;
        }

        // =========================================
        // LOGOUT
        // =========================================

        protected void btnLogout_Click(
            object sender,
            EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("~/Account/Login.aspx");
        }
    }
}
