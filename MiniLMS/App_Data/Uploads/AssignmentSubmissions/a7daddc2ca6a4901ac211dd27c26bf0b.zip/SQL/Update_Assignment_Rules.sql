﻿USE [MiniLMSDb];
GO

-- 1. Eligibility is based on account status and role only.
--    Course ProgramID and YearLevel remain metadata, NOT assignment restrictions.
CREATE OR ALTER PROCEDURE dbo.ECourseStudents_GetEligible
    @CourseID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT U.UserID AS StudentID,
           CONCAT(U.FirstName, ' ', U.LastName) AS StudentName
    FROM dbo.EUsers AS U
    WHERE EXISTS (SELECT 1 FROM dbo.ECourses WHERE CourseID = @CourseID)
      AND U.Role = 'Student'
      AND U.IsApproved = 1
      AND U.IsActive = 1
      AND NOT EXISTS (
          SELECT 1 FROM dbo.ECourseStudents AS CS
          WHERE CS.CourseID = @CourseID AND CS.StudentID = U.UserID
      )
    ORDER BY U.FirstName, U.LastName;
END;
GO

-- 2. Admin may assign any approved, active student to any existing course.
CREATE OR ALTER PROCEDURE dbo.ECourseStudents_Assign
    @CourseID INT,
    @StudentID INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.ECourses WHERE CourseID = @CourseID)
        THROW 50011, 'Course does not exist.', 1;
    IF NOT EXISTS (
        SELECT 1 FROM dbo.EUsers
        WHERE UserID = @StudentID AND Role = 'Student'
          AND IsApproved = 1 AND IsActive = 1
    )
        THROW 50012, 'Only approved, active students can be assigned.', 1;

    IF NOT EXISTS (
        SELECT 1 FROM dbo.ECourseStudents WITH (UPDLOCK, HOLDLOCK)
        WHERE CourseID = @CourseID AND StudentID = @StudentID
    )
    BEGIN
        INSERT INTO dbo.ECourseStudents (CourseID, StudentID)
        VALUES (@CourseID, @StudentID);
    END;
END;
GO

-- 3. Student course details must use admin course assignments as the
--    source of access, not require a separate EEnrollment record.
--    Keep optional progress data if an EEnrollment row happens to exist.
CREATE OR ALTER VIEW dbo.vw_StudentCourseDetails
AS
SELECT CS.StudentID,
       C.CourseID,
       C.CourseTitle,
       C.CourseDescription,
       CONCAT(U.FirstName, ' ', U.LastName) AS InstructorName,
       E.LastAccessedLessonID,
       L.LessonTitle AS LastAccessedLessonTitle,
       COALESCE(E.Status, 'Assigned') AS EnrollmentStatus
FROM dbo.ECourseStudents AS CS
INNER JOIN dbo.ECourses AS C ON C.CourseID = CS.CourseID
INNER JOIN dbo.EUsers AS U ON U.UserID = C.InstructorID
LEFT JOIN dbo.EEnrollment AS E
    ON E.CourseID = CS.CourseID AND E.StudentID = CS.StudentID
LEFT JOIN dbo.ELessons AS L ON L.LessonID = E.LastAccessedLessonID
WHERE C.CoursePublished = 1;
GO
