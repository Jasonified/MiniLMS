﻿
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniLMS.Admin
{
    public partial class ManageCourses : Page
    {
        private string ConnectionString
        {
            get
            {
                return ConfigurationManager
                    .ConnectionStrings["EMiniLMSConnection"]
                    .ConnectionString;
            }
        }

        protected void Page_Load(object sender, EventArgs e)

        {


            if (Session["UserID"] == null ||
                !string.Equals(
                    Convert.ToString(Session["Role"]),
                    "Admin",
                    StringComparison.OrdinalIgnoreCase))
            {
                Response.Redirect("~/Account/Login.aspx", false);
                Context.ApplicationInstance.CompleteRequest();
                return;
            }

            if (!IsPostBack)
            {
                LoadPrograms();
                LoadAssignmentPrograms();
                LoadInstructors();
                LoadCourses();
                LoadCourseDropdown();
                LoadStudents();
                LoadAssignedStudents();
                LoadStatistics();
                ClearCourseForm();
            }
        }

        // =====================================
        // DATABASE HELPERS
        // =====================================

        private DataTable GetProcedureData(
            string procedure,
            params SqlParameter[] parameters)
        {
            DataTable table = new DataTable();

            using (SqlConnection con =
                new SqlConnection(ConnectionString))
            using (SqlCommand cmd =
                new SqlCommand(procedure, con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }

        private void ExecuteProcedure(
            string procedure,
            params SqlParameter[] parameters)
        {
            using (SqlConnection con =
                new SqlConnection(ConnectionString))
            using (SqlCommand cmd =
                new SqlCommand(procedure, con))
            {
                cmd.CommandType =
                    CommandType.StoredProcedure;

                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        private static SqlParameter P(
            string name,
            object value)
        {
            return new SqlParameter(
                name,
                value ?? DBNull.Value);
        }

        private void ShowMessage(
            string message,
            bool success)
        {
            lblMessage.Text =
                HttpUtility.HtmlEncode(message);

            lblMessage.ForeColor = success
                ? System.Drawing.Color.DarkGreen
                : System.Drawing.Color.DarkRed;
        }

        private void OpenTab(string tab)
        {
            string selected =
                tab == "instructors" || tab == "students"
                    ? tab
                    : "courses";

            string script =
                "sessionStorage.setItem(" +
                "'MiniLMS.ManageCourses.activeTab'," +
                "'" + selected + "');";

            ClientScript.RegisterStartupScript(
                GetType(),
                "SelectManageCoursesTab",
                script,
                true);
        }

        private void SelectIfExists(
            DropDownList dropdown,
            object value)
        {
            string selected =
                value == null || value == DBNull.Value
                    ? ""
                    : Convert.ToString(value);

            ListItem item =
                dropdown.Items.FindByValue(selected);

            if (item != null)
            {
                dropdown.ClearSelection();
                item.Selected = true;
            }
        }

        // =====================================
        // PROGRAMS
        // =====================================




        // Load active programs for the Create/Edit Course dropdown.
        // Value = ProgramID, displayed text = ProgramCode.
        private void LoadPrograms()
        {
            DataTable dt = GetProcedureData("dbo.EPrograms_Web");
            string previous = ddlProgram.SelectedValue;

            ddlProgram.Items.Clear();
            ddlProgram.Items.Add(new ListItem("-- Select Program --", ""));

            foreach (DataRow row in dt.Rows)
            {
                ddlProgram.Items.Add(new ListItem(
                    Convert.ToString(row["ProgramCode"]),
                    Convert.ToString(row["ProgramID"])));
            }

            SelectIfExists(ddlProgram, previous);
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (Session["UserID"] != null &&
                string.Equals(
                    Convert.ToString(Session["Role"]),
                    "Admin",
                    StringComparison.OrdinalIgnoreCase) &&
                ddlProgram.Items.Count <= 1)
            {
                LoadPrograms();
            }

            base.OnPreRender(e);
        }


        // =====================================
        // INSTRUCTORS
        // =====================================

        private void LoadInstructors()
        {
            DataTable dt = GetProcedureData("dbo.EUsers_GetActiveInstructors");

            ddlInstructor.DataSource = dt;
            ddlInstructor.DataTextField =
                "InstructorName";
            ddlInstructor.DataValueField = "UserID";
            ddlInstructor.DataBind();

            ddlInstructor.Items.Insert(
                0,
                new ListItem("-- Select Instructor --", ""));
        }

        // =====================================
        // COURSES
        // =====================================

        private void LoadCourses()
        {
            // Include program names and group the course list by program.
            const string sql = @"
                SELECT C.CourseID, C.CourseTitle,
                       COALESCE(P.ProgramCode, 'Unassigned') AS ProgramCode,
                       C.YearLevel, C.Semester,
                       CONCAT(U.FirstName, ' ', U.LastName) AS InstructorName,
                       C.CoursePublished,
                       (SELECT COUNT(*) FROM dbo.ECourseStudents CS
                        WHERE CS.CourseID = C.CourseID) AS StudentCount
                FROM dbo.ECourses C
                LEFT JOIN dbo.EPrograms P ON P.ProgramID = C.ProgramID
                LEFT JOIN dbo.EUsers U ON U.UserID = C.InstructorID
                ORDER BY P.ProgramCode, C.YearLevel, C.Semester, C.CourseTitle";
            DataTable dt = GetSqlData(sql);
            gvCourses.DataSource = dt;
            gvCourses.DataBind();
        }

        // Both filters use the same active-program stored procedure.
        // All Courses: ProgramCode value for client-side filtering.
        // Assign Students: ProgramID value for SQL course filtering.
        private void LoadAssignmentPrograms()
        {
            DataTable dt = GetProcedureData("dbo.EPrograms_Web");
            string previousCourses = ddlAllCoursesProgram.SelectedValue;
            string previousAssignment = ddlAssignProgram.SelectedValue;

            ddlAllCoursesProgram.Items.Clear();
            ddlAssignProgram.Items.Clear();
            ddlAllCoursesProgram.Items.Add(new ListItem("All programs", ""));
            ddlAssignProgram.Items.Add(new ListItem("All programs", ""));

            foreach (DataRow row in dt.Rows)
            {
                string code = Convert.ToString(row["ProgramCode"]);
                string id = Convert.ToString(row["ProgramID"]);
                ddlAllCoursesProgram.Items.Add(new ListItem(code, code));
                ddlAssignProgram.Items.Add(new ListItem(code, id));
            }

            SelectIfExists(ddlAllCoursesProgram, previousCourses);
            SelectIfExists(ddlAssignProgram, previousAssignment);
        }

        private void SetAssignmentFiltersForCourse(int courseID)
        {
            DataTable dt = GetSqlData(
                "SELECT ProgramID, YearLevel, Semester FROM dbo.ECourses WHERE CourseID = @CourseID",
                P("@CourseID", courseID));
            if (dt.Rows.Count == 0) return;
            DataRow row = dt.Rows[0];
            SelectIfExists(ddlAssignProgram, row["ProgramID"]);
            SelectIfExists(ddlAssignYear, row["YearLevel"]);
            SelectIfExists(ddlAssignSemester, row["Semester"]);
        }

        private void LoadCourseDropdown(int? selectedCourseID = null)
        {
            string previous = selectedCourseID.HasValue
                ? selectedCourseID.Value.ToString()
                : ddlEnrollmentCourse.SelectedValue;

            int programID, yearLevel, semester;
            object program = int.TryParse(ddlAssignProgram.SelectedValue, out programID)
                ? (object)programID : DBNull.Value;
            object year = int.TryParse(ddlAssignYear.SelectedValue, out yearLevel)
                ? (object)yearLevel : DBNull.Value;
            object term = int.TryParse(ddlAssignSemester.SelectedValue, out semester)
                ? (object)semester : DBNull.Value;

            const string sql = @"
                SELECT CourseID, CourseTitle
                FROM dbo.ECourses
                WHERE (@ProgramID IS NULL OR ProgramID = @ProgramID)
                  AND (@YearLevel IS NULL OR YearLevel = @YearLevel)
                  AND (@Semester IS NULL OR Semester = @Semester)
                ORDER BY CourseTitle, CourseID";
            DataTable dt = GetSqlData(sql,
                P("@ProgramID", program), P("@YearLevel", year), P("@Semester", term));

            ddlEnrollmentCourse.DataSource = dt;
            ddlEnrollmentCourse.DataTextField = "CourseTitle";
            ddlEnrollmentCourse.DataValueField = "CourseID";
            ddlEnrollmentCourse.DataBind();
            ddlEnrollmentCourse.Items.Insert(0, new ListItem("-- Select Course --", ""));
            SelectIfExists(ddlEnrollmentCourse, previous);
        }

        protected void AssignmentFilter_Changed(object sender, EventArgs e)
        {
            // Filters change the available courses; don't retain an unrelated course.
            ddlEnrollmentCourse.ClearSelection();
            LoadCourseDropdown();
            LoadStudents();
            LoadAssignedStudents();
            OpenTab("students");
        }

        // =====================================
        // ELIGIBLE STUDENTS
        // =====================================

        private void LoadStudents()
        {
            cblEligibleStudents.Items.Clear();
            int courseID;
            if (!int.TryParse(ddlEnrollmentCourse.SelectedValue, out courseID))
            {
                lblEligibleInfo.Text = "Select a course to see matching students.";
                return;
            }

            // Approved, active students from any program or year level.
            // Exclude students already assigned to this course.
            const string sql = @"
                SELECT U.UserID AS StudentID,
                       CONCAT(U.FirstName, ' ', U.LastName, ' (', U.Email, ')') AS StudentName
                FROM dbo.EUsers U
                INNER JOIN dbo.ECourses C ON C.CourseID = @CourseID
                WHERE U.Role = 'Student'
                  AND U.IsApproved = 1 AND U.IsActive = 1
                  AND NOT EXISTS (
                      SELECT 1 FROM dbo.ECourseStudents CS
                      WHERE CS.CourseID = C.CourseID AND CS.StudentID = U.UserID
                  )
                ORDER BY U.LastName, U.FirstName, U.UserID;";

            DataTable dt = GetSqlData(sql, P("@CourseID", courseID));
            cblEligibleStudents.DataSource = dt;
            cblEligibleStudents.DataTextField = "StudentName";
            cblEligibleStudents.DataValueField = "StudentID";
            cblEligibleStudents.DataBind();
            lblEligibleInfo.Text = dt.Rows.Count == 0
                ? "No available unassigned students for this course."
                : dt.Rows.Count + " eligible, unassigned student(s) available.";
        }

        private DataTable GetSqlData(string sql, params SqlParameter[] parameters)
        {
            var table = new DataTable();
            using (var con = new SqlConnection(ConnectionString))
            using (var cmd = new SqlCommand(sql, con))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                using (var adapter = new SqlDataAdapter(cmd)) adapter.Fill(table);
            }
            return table;
        }

        // =====================================
        // ASSIGNED STUDENTS
        // =====================================


        private void LoadAssignedStudents()
        {
            int courseID;
            if (!int.TryParse(ddlEnrollmentCourse.SelectedValue, out courseID))
            {
                gvEnrolledStudents.DataSource = null;
                gvEnrolledStudents.DataBind();
                return;
            }
            const string sql = @"
                SELECT CS.CourseStudentID, CS.CourseID, CS.StudentID,
                       CONCAT(U.FirstName, ' ', U.LastName) AS StudentName,
                       U.Email, 'Assigned' AS Status, CS.AssignedAt
                FROM dbo.ECourseStudents CS
                INNER JOIN dbo.EUsers U ON U.UserID = CS.StudentID
                WHERE CS.CourseID = @CourseID
                ORDER BY CS.AssignedAt DESC;";
            gvEnrolledStudents.DataSource = GetSqlData(sql, P("@CourseID", courseID));
            gvEnrolledStudents.DataBind();
        }

        // =====================================
        // STATISTICS
        // =====================================

        private void LoadStatistics()
        {
            DataTable dt = GetProcedureData("dbo.ECourses_GetStatistics");

            if (dt.Rows.Count == 0)
                return;

            DataRow row = dt.Rows[0];

            lblTotalCourses.Text =
                row["TotalCourses"].ToString();

            lblPublishedCourses.Text =
                row["PublishedCourses"].ToString();

            lblTotalEnrollments.Text =
                row["TotalEnrollments"].ToString();
        }

        private void RefreshAll()
        {
            LoadPrograms();
            LoadCourses();
            LoadAssignmentPrograms();
            LoadCourseDropdown();
            LoadStudents();
            LoadAssignedStudents();
            LoadStatistics();
        }

        // =====================================
        // CLEAR COURSE FORM
        // =====================================

        private void ClearCourseForm()
        {
            hfCourseID.Value = "0";

            txtCourseTitle.Text = "";
            txtDescription.Text = "";
            txtAnnouncement.Text = "";

            chkPublished.Checked = false;

            ddlInstructor.ClearSelection();
            ddlProgram.ClearSelection();
            ddlYearLevel.ClearSelection();
            ddlSemester.ClearSelection();

            btnSaveCourse.Text = "Save Course";
        }

        protected void btnClear_Click(
            object sender,
            EventArgs e)
        {
            ClearCourseForm();
            OpenTab("instructors");
        }

        // =====================================
        // SAVE COURSE
        // =====================================

        protected void btnSaveCourse_Click(
            object sender,
            EventArgs e)
        {
            int courseID = 0;
            int instructorID;
            int programID;
            int yearLevel;
            int semester;

            int.TryParse(
                hfCourseID.Value,
                out courseID);

            if (string.IsNullOrWhiteSpace(
                txtCourseTitle.Text))
            {
                ShowMessage(
                    "Please enter a course title.",
                    false);
                OpenTab("instructors");
                return;
            }

            if (!int.TryParse(
                ddlInstructor.SelectedValue,
                out instructorID) ||
                !int.TryParse(
                ddlProgram.SelectedValue,
                out programID) ||
                !int.TryParse(
                ddlYearLevel.SelectedValue,
                out yearLevel) ||
                !int.TryParse(
                ddlSemester.SelectedValue,
                out semester))
            {
                ShowMessage(
                    "Please select an instructor, " +
                    "program, year level, and semester.",
                    false);

                OpenTab("instructors");
                return;
            }

            try
            {
                ExecuteProcedure(
                    "dbo.ECourses_WebSave",

                    P("@CourseID", courseID),
                    P("@InstructorID", instructorID),

                    P(
                        "@CourseTitle",
                        txtCourseTitle.Text.Trim()),

                    P(
                        "@CourseDescription",
                        txtDescription.Text.Trim()),

                    P(
                        "@Announcement",
                        txtAnnouncement.Text.Trim()),

                    P(
                        "@CoursePublished",
                        chkPublished.Checked),

                    P("@ProgramID", programID),
                    P("@YearLevel", yearLevel),
                    P("@Semester", semester)
                );

                ClearCourseForm();
                RefreshAll();

                ShowMessage(
                    "Course saved successfully.",
                    true);

                OpenTab("courses");
            }
            catch (SqlException ex)
            {
                ShowMessage(ex.Message, false);
                OpenTab("instructors");
            }
        }

        // =====================================
        // COURSE GRID ACTIONS
        // =====================================

        protected void gvCourses_RowCommand(
            object sender,
            GridViewCommandEventArgs e)
        {
            int courseID;

            if (!int.TryParse(
                Convert.ToString(e.CommandArgument),
                out courseID))
                return;

            try
            {
                if (e.CommandName == "EditCourse")
                {
                    EditCourse(courseID);
                    OpenTab("instructors");
                }
                else if (e.CommandName == "SelectCourse")
                {
                    SetAssignmentFiltersForCourse(courseID);
                    LoadCourseDropdown(courseID);
                    LoadStudents();
                    LoadAssignedStudents();

                    OpenTab("students");
                }
                else if (e.CommandName == "DeleteCourse")
                {
                    ExecuteProcedure(
                        "dbo.ECourses_WebDelete",
                        P("@CourseID", courseID));

                    RefreshAll();

                    ShowMessage(
                        "Course deleted successfully.",
                        true);

                    OpenTab("courses");
                }
            }
            catch (SqlException ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        // =====================================
        // EDIT COURSE
        // =====================================

        private void EditCourse(int courseID)
        {
            DataTable dt = GetProcedureData("dbo.ECourses_GetByID",
                P("@CourseID", courseID));

            if (dt.Rows.Count == 0)
            {
                ShowMessage(
                    "Course not found.",
                    false);
                return;
            }

            DataRow row = dt.Rows[0];

            hfCourseID.Value =
                row["CourseID"].ToString();

            txtCourseTitle.Text =
                row["CourseTitle"].ToString();

            txtDescription.Text =
                row["CourseDescription"].ToString();

            txtAnnouncement.Text =
                row["Announcement"].ToString();

            chkPublished.Checked =
                Convert.ToBoolean(
                    row["CoursePublished"]);

            SelectIfExists(
                ddlInstructor,
                row["InstructorID"]);

            SelectIfExists(
                ddlProgram,
                row["ProgramID"]);

            SelectIfExists(
                ddlYearLevel,
                row["YearLevel"]);

            SelectIfExists(
                ddlSemester,
                row["Semester"]);

            btnSaveCourse.Text = "Update Course";

            ShowMessage(
                "Editing: " + txtCourseTitle.Text,
                true);
        }

        // =====================================
        // COURSE DROPDOWN CHANGE
        // =====================================

        protected void ddlEnrollmentCourse_SelectedIndexChanged(
            object sender,
            EventArgs e)
        {
            LoadStudents();
            LoadAssignedStudents();
            OpenTab("students");
        }

        // =====================================
        // ASSIGN STUDENT
        // =====================================

        protected void btnEnroll_Click(object sender, EventArgs e)
        {
            int courseID;
            if (!int.TryParse(ddlEnrollmentCourse.SelectedValue, out courseID))
            {
                ShowMessage("Please select a course first.", false);
                OpenTab("students");
                return;
            }

            var selected = new List<int>();
            foreach (ListItem item in cblEligibleStudents.Items)
            {
                int studentID;
                if (item.Selected && int.TryParse(item.Value, out studentID))
                    selected.Add(studentID);
            }
            if (selected.Count == 0)
            {
                ShowMessage("Select at least one eligible student.", false);
                OpenTab("students");
                return;
            }

            try
            {
                // Recheck eligibility at save time (do not trust client selection).
                const string sql = @"
                    SELECT U.UserID AS StudentID
                    FROM dbo.EUsers U
                    INNER JOIN dbo.ECourses C ON C.CourseID = @CourseID
                    WHERE U.Role='Student' AND U.IsApproved=1 AND U.IsActive=1
                      AND NOT EXISTS (SELECT 1 FROM dbo.ECourseStudents CS
                                      WHERE CS.CourseID=C.CourseID AND CS.StudentID=U.UserID);";
                DataTable valid = GetSqlData(sql, P("@CourseID", courseID));
                var allowed = new HashSet<int>();
                foreach (DataRow row in valid.Rows)
                    allowed.Add(Convert.ToInt32(row["StudentID"]));

                int skipped = selected.Count(id => !allowed.Contains(id));
                var toAssign = selected.Where(id => allowed.Contains(id)).Distinct().ToList();

                // The stored procedure must enforce active/approved status,
                // not matching program or year level.
                // One transaction: either all selected valid assignments save, or none do.
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    using (var tx = con.BeginTransaction())
                    {
                        try
                        {
                            foreach (int studentID in toAssign)
                            {
                                using (var cmd = new SqlCommand("dbo.ECourseStudents_Assign", con, tx))
                                {
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.Parameters.Add("@CourseID", SqlDbType.Int).Value = courseID;
                                    cmd.Parameters.Add("@StudentID", SqlDbType.Int).Value = studentID;
                                    cmd.ExecuteNonQuery();
                                }
                            }
                            tx.Commit();
                        }
                        catch
                        {
                            tx.Rollback();
                            throw;
                        }
                    }
                }

                RefreshAll();
                ShowMessage(toAssign.Count + " student(s) assigned. " + skipped +
                    " skipped because eligibility or assignment status changed.", true);
            }
            catch (Exception ex)
            {
                ShowMessage("Unable to assign students: " + ex.Message, false);
                LoadStudents();
            }
            OpenTab("students");
        }

        // =====================================
        // REMOVE STUDENT
        // =====================================

        protected void gvEnrolledStudents_RowCommand(
            object sender,
            GridViewCommandEventArgs e)
        {
            if (e.CommandName != "RemoveStudent")
                return;

            int courseStudentID;

            if (!int.TryParse(
                Convert.ToString(e.CommandArgument),
                out courseStudentID))
                return;

            try
            {
                DataTable dt = GetSqlData(
                    "SELECT CourseID, StudentID FROM dbo.ECourseStudents WHERE CourseStudentID = @ID",
                    P("@ID", courseStudentID));

                if (dt.Rows.Count == 0)
                {
                    ShowMessage(
                        "Student assignment not found.",
                        false);
                    OpenTab("students");
                    return;
                }

                int courseID =
                    Convert.ToInt32(
                        dt.Rows[0]["CourseID"]);

                int studentID =
                    Convert.ToInt32(
                        dt.Rows[0]["StudentID"]);

                ExecuteProcedure(
                    "dbo.ECourseStudents_Remove",

                    P("@CourseID", courseID),
                    P("@StudentID", studentID)
                );

                RefreshAll();

                ShowMessage(
                    "Student removed successfully.",
                    true);
            }
            catch (SqlException ex)
            {
                ShowMessage(ex.Message, false);
            }

            OpenTab("students");
        }

        // =====================================
        // LOGOUT
        // =====================================

        protected void btnLogout_Click(
            object sender,
            EventArgs e)
        {
            Session.Clear();
            Session.Abandon();

            Response.Redirect(
                "~/Account/Login.aspx",
                false);

            Context.ApplicationInstance.CompleteRequest();
        }
    }
}
