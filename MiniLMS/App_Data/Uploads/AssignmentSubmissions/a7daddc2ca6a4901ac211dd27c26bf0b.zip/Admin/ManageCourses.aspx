﻿
<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="ManageCourses.aspx.cs"
    Inherits="MiniLMS.Admin.ManageCourses" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>MiniLMS | Manage Courses</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f4f7fb;
            color: #142c49;
        }

        .topbar {
            background: #061a33;
            color: white;
            padding: 16px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .brand {
            font-size: 23px;
            font-weight: 800;
            letter-spacing: -0.7px;
        }

        .brand span {
            color: #8ebeff;
        }

        .nav {
            display: flex;
            gap: 7px;
            align-items: center;
            flex-wrap: wrap;
        }

        .nav a,
        .logout {
            font-family: inherit;
            font-size: 13px;
            color: #d8e7f7;
            padding: 10px 14px;
            border-radius: 8px;
            text-decoration: none;
            border: 0;
            background: transparent;
            cursor: pointer;
        }

        .nav a:hover,
        .nav a.active {
            background: #173f6b;
            color: white;
        }

        .logout {
            border: 1px solid #54708e;
            color: white;
        }

        .logout:hover {
            background: #183d65;
        }

        .wrap {
            max-width: 1280px;
            margin: 0 auto;
            padding: 36px 24px 60px;
        }

        .heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }

        h1 {
            font-size: 29px;
            color: #0b2d55;
            margin: 0 0 7px;
        }

        .muted {
            color: #71839b;
            font-size: 13px;
            line-height: 1.6;
            margin: 0;
        }

        .admin-tag {
            background: #e7eff9;
            border: 1px solid #d6e4f3;
            color: #174577;
            border-radius: 30px;
            padding: 9px 14px;
            font-size: 12px;
            font-weight: 700;
        }

        .section-title {
            font-size: 17px;
            font-weight: 700;
            margin: 0 0 17px;
        }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 17px;
            margin-bottom: 32px;
        }

        .stat-box {
            background: white;
            border: 1px solid #e1e9f2;
            border-radius: 13px;
            padding: 22px;
            box-shadow: 0 3px 12px rgba(18,54,93,0.03);
        }

        .stat-label {
            color: #71839b;
            font-size: 13px;
            font-weight: 600;
        }

        .stat-value {
            display: block;
            color: #0b2d55;
            font-size: 31px;
            font-weight: 800;
            margin-top: 10px;
        }

        .tab-bar {
            display: flex;
            gap: 8px;
            padding: 7px;
            background: #eaf0f7;
            border: 1px solid #dce6f1;
            border-radius: 13px;
            margin-bottom: 22px;
            overflow-x: auto;
        }

        .tab-button {
            flex: 1;
            min-width: 175px;
            padding: 14px 16px;
            border: none;
            border-radius: 9px;
            background: transparent;
            color: #58708b;
            font-family: inherit;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            white-space: nowrap;
        }

        .tab-button:hover {
            background: #f8fbff;
            color: #0b2d55;
        }

        .tab-button.active {
            background: white;
            color: #0b2d55;
            box-shadow: 0 2px 9px rgba(11,45,85,0.09);
        }

        .tab-pane[hidden] {
            display: none !important;
        }

        .panel {
            background: white;
            border: 1px solid #e1e9f2;
            border-radius: 13px;
            overflow: hidden;
            margin-bottom: 22px;
            box-shadow: 0 3px 12px rgba(18,54,93,0.03);
        }

        .panel-head {
            padding: 23px;
            border-bottom: 1px solid #e8eef5;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
        }

        .panel-head h2 {
            margin: 0 0 5px;
            font-size: 18px;
        }

        .panel-body {
            padding: 23px;
        }

        #course-editor {
            max-width: 790px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 17px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            font-size: 12px;
            font-weight: 700;
            color: #425671;
        }

        .form-control {
            display: block;
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #d6e0eb;
            border-radius: 8px;
            background: white;
            font-family: inherit;
            font-size: 13px;
            color: #142c49;
        }

        .form-control:focus {
            outline: none;
            border-color: #18538f;
            box-shadow: 0 0 0 3px rgba(24,83,143,0.08);
        }

        textarea.form-control {
            min-height: 90px;
            resize: vertical;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 0 16px;
        }

        .checkbox-line {
            font-size: 13px;
            margin: 14px 0 18px;
        }

        .button-row {
            display: flex;
            gap: 9px;
            flex-wrap: wrap;
        }

        .btn {
            border: none;
            border-radius: 8px;
            padding: 11px 16px;
            font-family: inherit;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
        }

        .btn-primary {
            background: #0b2d55;
            color: white;
        }

        .btn-primary:hover {
            background: #164f8c;
        }

        .btn-secondary {
            background: #e8eff7;
            color: #174577;
        }

        .message-area {
            margin-bottom: 15px;
        }

        .message {
            display: block;
            font-size: 13px;
            line-height: 1.6;
        }

        .table-wrap {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            min-width: 760px;
            border-collapse: collapse;
        }

        .data-table th {
            background: #f8fafc;
            color: #60738b;
            padding: 15px 14px;
            font-size: 11px;
            text-align: left;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            white-space: nowrap;
        }

        .data-table td {
            padding: 15px 14px;
            border-top: 1px solid #edf1f6;
            font-size: 13px;
            color: #34475e;
            vertical-align: middle;
        }

        .data-table tr:hover td {
            background: #f9fbfe;
        }

        .table-action {
            display: inline-block;
            color: #18538f;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            margin-right: 11px;
            padding: 4px 0;
        }

        .table-action:hover {
            text-decoration: underline;
        }

        .table-action.danger {
            color: #b4232d;
        }

        .hint {
            font-size: 12px;
            color: #71839b;
            line-height: 1.6;
        }

        .student-form {
            display: grid;
            grid-template-columns:
                minmax(220px, 1fr)
                minmax(220px, 1fr)
                auto;
            align-items: end;
            gap: 16px;
        }

        .student-form .form-group {
            margin: 0;
        }

        .student-form .hint {
            grid-column: 1 / -1;
            margin: 0;
        }

        @media (max-width: 900px) {
            .stat-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .student-form {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 600px) {
            .wrap {
                padding: 24px 15px;
            }

            .stat-grid,
            .form-grid {
                grid-template-columns: 1fr;
            }

            .tab-button {
                min-width: 140px;
                padding: 12px 10px;
                font-size: 12px;
            }

            .panel-head,
            .panel-body {
                padding: 18px;
            }

            h1 {
                font-size: 25px;
            }
        }

        .course-program-toolbar { padding:18px 23px; display:flex; gap:14px; align-items:center; flex-wrap:wrap; background:#f8fbff; border-bottom:1px solid #e8eef5; }
        .course-program-toolbar .form-label { margin:0; }
        .course-program-toolbar select { max-width:260px; }
        #<%= gvCourses.ClientID %> td:first-child { font-weight:700; color:#174577; }
        /* Course-first assignment */
        .assignment-course-picker { max-width:600px; margin-bottom:28px; }
        .assignment-list-heading { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:14px; }
        .assignment-list-heading h3 { margin:0 0 5px; font-size:16px; }
        .assignment-count { font-size:12px; font-weight:700; color:#174577; background:#e7eff9; padding:8px 12px; border-radius:30px; }
        .assignment-toolbar { display:flex; align-items:center; gap:9px; flex-wrap:wrap; margin-bottom:14px; }
        .assignment-toolbar .form-control { flex:1 1 260px; }
        .eligible-student-list { max-height:340px; overflow-y:auto; border:1px solid #dce6f1; border-radius:11px; padding:10px; background:#fbfdff; margin-bottom:10px; }
        .eligible-checkbox-list { display:flex; flex-direction:column; gap:7px; }
        .eligible-checkbox-list > span { display:flex; align-items:center; gap:10px; padding:13px; border:1px solid #e2e8f0; border-radius:9px; background:white; cursor:pointer; }
        .eligible-checkbox-list > span:has(input:checked) { border-color:#32927e; background:#e9f7f2; }
        .eligible-checkbox-list input { accent-color:#16866e; width:17px; height:17px; }
        .eligible-checkbox-list label { cursor:pointer; font-size:13px; flex:1; }
        .assignment-footer { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px; border-top:1px solid #e8eef5; padding-top:18px; margin-top:20px; }
        .assignment-footer .hint { margin:5px 0 0; }
        @media(max-width:600px) { .assignment-toolbar .btn { flex:1; } .assignment-footer .btn { width:100%; } }

    
/* Option E shared top navigation: frontend-only */
:root{--nav-height:72px}
body{background:#f5f7fb!important}
.topbar,.sidebar{position:sticky!important;top:0!important;left:auto!important;right:auto!important;inset:auto!important;width:100%!important;height:var(--nav-height)!important;min-height:var(--nav-height)!important;overflow:visible!important;z-index:1000!important;display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:space-between!important;gap:24px!important;padding:0 34px!important;margin:0!important;background:#102e50!important;border:0!important;border-radius:0!important;box-shadow:0 1px 5px #102e5020!important;color:#fff!important;max-width:none!important}
.nav-left{display:flex;align-items:center;gap:36px;min-width:0}
.topbar .brand,.sidebar .brand{display:flex!important;align-items:center!important;gap:0!important;margin:0!important;padding:0!important;white-space:nowrap!important;font-size:22px!important;font-weight:800!important;color:#fff!important}
.topbar .brand span,.sidebar .brand span{color:#61a9f5!important}
.topbar .nav,.sidebar .sidebar-nav{display:flex!important;flex-direction:row!important;align-items:center!important;gap:6px!important;margin:0!important;padding:0!important;overflow:visible!important}
.topbar .nav a,.sidebar .sidebar-nav .menu-button{display:inline-flex!important;align-items:center!important;justify-content:center!important;width:auto!important;min-width:0!important;margin:0!important;padding:10px 15px!important;border:0!important;border-radius:8px!important;background:transparent!important;color:#d6e4f2!important;font:600 13px 'Segoe UI',Arial,sans-serif!important;text-decoration:none!important;white-space:nowrap!important;box-shadow:none!important;cursor:pointer!important}
.topbar .nav a:hover,.sidebar .sidebar-nav .menu-button:hover{background:#ffffff16!important;color:#fff!important}
.topbar .nav a.active,.sidebar .sidebar-nav .menu-active{background:#28598e!important;color:#fff!important}
.nav-account{margin-left:auto;position:relative;flex:none}
.nav-account summary{display:flex;align-items:center;gap:11px;cursor:pointer;list-style:none;padding:7px 10px;border-radius:9px;user-select:none;color:#fff}
.nav-account summary::-webkit-details-marker{display:none}
.nav-account summary:hover,.nav-account[open] summary{background:#ffffff17}
.nav-avatar{width:36px;height:36px;border-radius:50%;display:grid;place-items:center;overflow:hidden;flex:none;background:#e5eef9;color:#174b7e;font-weight:800;font-size:16px}
.nav-avatar img{width:100%;height:100%;object-fit:cover;display:block}
.nav-avatar svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.8}
.nav-user{display:flex;flex-direction:column;gap:3px;max-width:180px;min-width:0}
.nav-user strong{font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.nav-user small{font-size:11px;color:#c6d8ed}
.nav-chevron{font-size:13px;color:#c9d9eb;margin-left:3px}
.nav-dropdown{position:absolute;right:0;top:calc(100% + 10px);width:245px;background:#fff;border:1px solid #e0e7ef;border-radius:12px;box-shadow:0 16px 36px #102e5029;padding:8px;color:#20364d;z-index:1005}
.nav-dropdown:before{content:'';position:absolute;right:22px;top:-7px;width:12px;height:12px;transform:rotate(45deg);background:#fff;border-top:1px solid #e0e7ef;border-left:1px solid #e0e7ef}
.dropdown-caption{padding:12px 12px 13px;border-bottom:1px solid #edf1f6;margin-bottom:5px}
.dropdown-caption strong{display:block;font-size:13px}.dropdown-caption small{display:block;color:#718096;font-size:11px;margin-top:4px}
.dropdown-link,.nav-dropdown .logout,.nav-dropdown .logout-button{display:block!important;width:100%!important;padding:11px 12px!important;text-align:left!important;border:0!important;border-radius:7px!important;background:transparent!important;color:#2b435d!important;font:600 13px 'Segoe UI',Arial,sans-serif!important;text-decoration:none!important;cursor:pointer!important;margin:0!important}
.dropdown-link:hover{background:#f0f5fc!important}
.nav-dropdown .logout,.nav-dropdown .logout-button{color:#b43f46!important}
.nav-dropdown .logout:hover,.nav-dropdown .logout-button:hover{background:#fff0f1!important}
.sidebar .account-card,.sidebar .menu-label,.sidebar .logout-container{display:none!important}
.main{margin-left:0!important;max-width:none!important;min-height:calc(100vh - var(--nav-height))!important}
@media(max-width:760px){.topbar,.sidebar{padding:0 15px!important;gap:8px!important;height:66px!important;min-height:66px!important}.nav-left{gap:13px}.topbar .brand,.sidebar .brand{font-size:17px!important}.topbar .nav,.sidebar .sidebar-nav{gap:0!important}.topbar .nav a,.sidebar .sidebar-nav .menu-button{font-size:11px!important;padding:9px 7px!important}.nav-user{display:none}.nav-chevron{display:none}.nav-account summary{padding:5px}.nav-avatar{width:32px;height:32px}.nav-dropdown{right:-4px}.main{margin-left:0!important}}
@media(max-width:420px){.topbar .brand,.sidebar .brand{font-size:15px!important}.nav-left{gap:7px}.topbar .nav a,.sidebar .sidebar-nav .menu-button{padding:8px 5px!important;font-size:10px!important}}

</style>
<style>

/* =========================================================
   MiniLMS / Option E - Minimal Workspace design system
   Presentation-only styles; existing server controls preserved.
   ========================================================= */
:root{--ink:#172536;--sub:#697787;--line:#e6e9ee;--surface:#fff;--page:#f8f9fb;--nav:#0c213b;--accent:#245b98;--hover:#f5f7fa}
body{background:var(--page);color:var(--ink);font-family:'Segoe UI',system-ui,-apple-system,Arial,sans-serif;font-size:14px}
.topbar{background:var(--nav);padding:13px max(24px,calc((100% - 1320px)/2));min-height:66px;border-bottom:1px solid #29405a;box-shadow:none}
.brand{font-size:21px;letter-spacing:-.9px;font-weight:750}
.brand span{color:#a6c9f2}
.nav{gap:5px}.nav a,.logout{font-size:13px;font-weight:550;padding:9px 13px;border-radius:7px}
.nav a.active{background:#263f5e;color:#fff}.nav a:hover,.logout:hover{background:#263f5e}
.logout{border:1px solid #53667c}
.wrap{max-width:1320px;padding:38px 28px 72px}
.heading{margin-bottom:30px;align-items:flex-start}.heading h1,h1{color:#14263c;font-size:29px;font-weight:750;letter-spacing:-1.1px}
.muted,.hint{color:var(--sub);line-height:1.65}.admin-tag{background:#fff;color:#42556a;border:1px solid var(--line);border-radius:7px;font-weight:600;padding:8px 12px}
.section-title{font-size:13px;letter-spacing:.07em;text-transform:uppercase;color:#657284;font-weight:700;margin-bottom:13px}
.stats,.stat-grid{gap:12px;margin-bottom:30px}
.stat-card,.stat-box{border:1px solid var(--line);border-radius:10px;box-shadow:none;padding:21px 22px;background:#fff;position:relative}
.stat-card:before,.stat-box:before{content:'';display:block;width:27px;height:3px;background:#c6d8ec;border-radius:6px;margin-bottom:16px}
.stat-card.inactive:before{background:#e3b783}.stat-card.pending:before{background:#cbb5e5}
.stat-label{color:#687789;font-size:12px;font-weight:600}.stat-value{color:#172536;font-size:30px;font-weight:750;letter-spacing:-1px;margin-top:8px}
.panel{border:1px solid var(--line);border-radius:10px;box-shadow:none;background:#fff;margin-bottom:18px}
.panel-head{padding:21px 24px;border-color:var(--line)}.panel-head h2{font-size:17px;color:#1b2c3f;font-weight:700}
.panel-body{padding:24px}.count-pill,.assignment-count{border:1px solid #dce7f3;border-radius:6px;background:#f4f8fd;color:#2b5d90;font-size:12px}
.toolbar,.course-program-toolbar{background:#fff;border-color:var(--line);padding:17px 24px}
.form-control,.role-dropdown{border:1px solid #dce2e9;border-radius:7px;background:#fff;color:#233448;min-height:40px;font-size:13px;box-shadow:none}
.form-control:focus,.role-dropdown:focus{border-color:#4e83b8;box-shadow:0 0 0 3px rgba(54,112,173,.10);outline:0}
.form-label{color:#526276;font-weight:650;font-size:12px}
.data-table th{background:#fafbfc;color:#748092;font-size:10px;font-weight:700;letter-spacing:.075em;padding:14px 16px;border-bottom:1px solid var(--line)}
.data-table td{padding:16px;border-color:#edf0f3;color:#334458}.data-table tr:hover td{background:#f8fafc}
.user-name{color:#20364f}.user-email{color:#778497}.role-badge,.status-badge{border-radius:5px;font-weight:650;padding:5px 9px}
.role-badge{background:#eef3f9;color:#365d83}.status-active{background:#e9f5ed;color:#26744c}.status-inactive{background:#fff2e7;color:#a6662e}.status-pending{background:#f1edfa;color:#795ba0}
.btn{border-radius:7px;padding:10px 14px;font-size:12px;font-weight:650;transition:background .15s ease,transform .15s ease}
.btn:active{transform:translateY(1px)}.btn-primary{background:#244d7c;color:#fff}.btn-primary:hover{background:#193c65}
.btn-secondary{background:#f4f6f8;color:#40566e;border:1px solid #e1e7ed}.btn-secondary:hover{background:#e9eef4}
.btn-warning{background:#fff6ed;border-color:#f2dfcc;color:#a05d27}.btn-success{background:#edf8f0;border-color:#d5ecdc;color:#28764b}
.table-action{color:#2a5b90;font-weight:650}.table-action.danger{color:#b35450}
.table-footer{border-color:var(--line);background:#fcfcfd}.info-panel{background:#f5f8fc;border:1px solid #e0e8f1;border-radius:9px;color:#4b6178}
.tab-bar{display:flex;background:transparent;border:0;border-bottom:1px solid var(--line);border-radius:0;padding:0;gap:22px;margin-bottom:20px}
.tab-button{flex:0 0 auto;min-width:0;border-radius:0;padding:14px 3px;color:#738092;font-weight:650;font-size:13px;border-bottom:2px solid transparent}
.tab-button.active{background:transparent;box-shadow:none;border-bottom-color:#285e9b;color:#214c7a}
.tab-button:hover{background:transparent;color:#214c7a}
#course-editor{max-width:900px}.eligible-student-list{background:#fbfcfe;border-color:var(--line);border-radius:8px}
.eligible-checkbox-list > span{border-color:#e6ebf0;border-radius:7px}.eligible-checkbox-list > span:has(input:checked){background:#eff7f3;border-color:#9fc9b1}
.assignment-footer{border-color:var(--line)}
@media(max-width:760px){.topbar{padding:15px 18px}.wrap{padding:26px 16px 48px}.heading h1,h1{font-size:25px}.nav{width:100%;justify-content:flex-start}.panel-head,.panel-body{padding:18px}.stats,.stat-grid{gap:10px}.stat-card,.stat-box{padding:16px}.tab-bar{gap:16px}.tab-button{font-size:12px}.toolbar{padding:16px}}
@media(max-width:460px){.stats,.stat-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.stat-value{font-size:25px}.admin-tag{display:none}}

</style>
<style>

        /* Shared MiniLMS admin navbar: identical on every page. */
        .topbar {
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
            min-height: 76px;
            padding: 14px max(24px, calc((100% - 1280px) / 2));
            background: #061a33;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        }
        .topbar .brand {
            color: #fff;
            font-family: 'Segoe UI', Arial, sans-serif;
            font-size: 23px;
            font-weight: 800;
            line-height: 1.2;
            letter-spacing: -.7px;
            white-space: nowrap;
        }
        .topbar .brand span { color: #8ebeff; }
        .topbar .nav {
            display: flex;
            align-items: center;
            gap: 7px;
            flex-wrap: wrap;
        }
        .topbar .nav a, .topbar .logout {
            box-sizing: border-box;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 38px;
            padding: 10px 14px;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            font-size: 13px;
            font-weight: 400;
            line-height: 18px;
            color: #d8e7f7;
            background: transparent;
            border: 1px solid transparent;
            border-radius: 8px;
            text-decoration: none;
            cursor: pointer;
            white-space: nowrap;
        }
        .topbar .nav a:hover, .topbar .nav a.active {
            color: #fff;
            background: #173f6b;
        }
        .topbar .logout { color: #fff; border-color: #54708e; }
        .topbar .logout:hover { background: #183d65; }
        @media (max-width: 650px) {
            .topbar { padding: 12px 16px; gap: 10px; }
            .topbar .nav { width: 100%; gap: 4px; }
            .topbar .nav a, .topbar .logout { padding: 8px 10px; font-size: 12px; }
        }
</style>
</head>

<body>
    <form id="form1" runat="server">

        <!-- NAVIGATION -->
        <header class="topbar"><div class="nav-left"><div class="brand">Mini<span>LMS</span></div><nav class="nav" aria-label="Admin navigation"><a class="" href="<%= ResolveUrl("~/Admin/AdminDashboard.aspx") %>">Dashboard</a><a class="" href="<%= ResolveUrl("~/Admin/ManageUsers.aspx") %>">Users</a><a class="active" href="<%= ResolveUrl("~/Admin/ManageCourses.aspx") %>">Courses</a></nav></div><details class="nav-account"><summary aria-label="Open account menu"><span class="nav-avatar">A</span><span class="nav-user"><strong>Admin Account</strong><small>Administrator</small></span><span class="nav-chevron">⌄</span></summary><div class="nav-dropdown"><div class="dropdown-caption"><strong>Admin Account</strong><small>Administrator account</small></div><asp:Button ID="btnLogout" runat="server" Text="↪  Logout" CssClass="logout-button" OnClick="btnLogout_Click" CausesValidation="false" /></div></details></header>

        <main class="wrap">

            <!-- PAGE HEADER -->
            <div class="heading">
                <div>
                    <h1>Manage Courses</h1>
                    <p class="muted">
                        Create courses, assign instructors,
                        and manage student assignments.
                    </p>
                </div>

                <span class="admin-tag">
                    Administrator
                </span>
            </div>

            <!-- OVERVIEW -->
            <h2 class="section-title">
                Course Overview
            </h2>

            <section class="stat-grid">

                <div class="stat-box">
                    <span class="stat-label">
                        Total Courses
                    </span>

                    <asp:Label
                        ID="lblTotalCourses"
                        runat="server"
                        Text="0"
                        CssClass="stat-value" />
                </div>

                <div class="stat-box">
                    <span class="stat-label">
                        Published Courses
                    </span>

                    <asp:Label
                        ID="lblPublishedCourses"
                        runat="server"
                        Text="0"
                        CssClass="stat-value" />
                </div>

                <div class="stat-box">
                    <span class="stat-label">
                        Student Assignments
                    </span>

                    <asp:Label
                        ID="lblTotalEnrollments"
                        runat="server"
                        Text="0"
                        CssClass="stat-value" />
                </div>

            </section>

            <!-- TABS -->
            <div class="tab-bar" role="tablist">

                <button type="button"
                    id="tab-courses"
                    class="tab-button active"
                    data-tab="courses">
                    All Courses
                </button>

                <button type="button"
                    id="tab-instructors"
                    class="tab-button"
                    data-tab="instructors">
                    Course Editor
                </button>

                <button type="button"
                    id="tab-students"
                    class="tab-button"
                    data-tab="students">
                    Assign Students
                </button>

            </div>

            <!-- MESSAGES -->
            <div class="message-area">
                <asp:Label
                    ID="lblMessage"
                    runat="server"
                    CssClass="message"
                    EnableViewState="false" />
            </div>

            <!-- ALL COURSES -->
            <div id="pane-courses"
                class="tab-pane active"
                role="tabpanel">

                <section class="panel">

                    <div class="panel-head">
                        <div>
                            <h2>All Courses</h2>
                            <p class="muted">
                                View and manage existing courses.
                            </p>
                        </div>

                        <button type="button"
                            class="btn btn-primary"
                            data-open-tab="instructors">
                            + Create Course
                        </button>
                    </div>

                    <div class="course-program-toolbar">
                        <label for="<%= ddlAllCoursesProgram.ClientID %>" class="form-label">Show courses by program</label>
                        <asp:DropDownList ID="ddlAllCoursesProgram" runat="server"
                            CssClass="form-control" onchange="filterCoursesByProgram()" />
                        <span class="hint" id="courseProgramCount">Courses grouped by program, year and semester</span>
                    </div>
                    <div class="table-wrap">

                        <asp:GridView
                            ID="gvCourses"
                            runat="server"
                            AutoGenerateColumns="False"
                            CssClass="data-table"
                            GridLines="None"
                            EmptyDataText="No courses available."
                            OnRowCommand="gvCourses_RowCommand">

                            <Columns>

                                <asp:BoundField
                                    DataField="CourseID"
                                    HeaderText="ID" />

                                <asp:BoundField
                                    DataField="ProgramCode"
                                    HeaderText="Program" />

                                <asp:BoundField
                                    DataField="YearLevel"
                                    HeaderText="Year" />

                                <asp:BoundField
                                    DataField="Semester"
                                    HeaderText="Semester" />

                                <asp:BoundField
                                    DataField="CourseTitle"
                                    HeaderText="Course" />

                                <asp:BoundField
                                    DataField="InstructorName"
                                    HeaderText="Instructor" />

                                <asp:BoundField
                                    DataField="CoursePublished"
                                    HeaderText="Published" />

                                <asp:BoundField
                                    DataField="StudentCount"
                                    HeaderText="Students" />

                                <asp:TemplateField HeaderText="Actions">
                                    <ItemTemplate>

                                        <asp:LinkButton
                                            ID="btnEdit"
                                            runat="server"
                                            Text="Edit"
                                            CssClass="table-action"
                                            CommandName="EditCourse"
                                            CommandArgument='<%# Eval("CourseID") %>'
                                            CausesValidation="false" />

                                        <asp:LinkButton
                                            ID="btnSelect"
                                            runat="server"
                                            Text="Students"
                                            CssClass="table-action"
                                            CommandName="SelectCourse"
                                            CommandArgument='<%# Eval("CourseID") %>'
                                            CausesValidation="false" />

                                        <asp:LinkButton
                                            ID="btnDelete"
                                            runat="server"
                                            Text="Delete"
                                            CssClass="table-action danger"
                                            CommandName="DeleteCourse"
                                            CommandArgument='<%# Eval("CourseID") %>'
                                            CausesValidation="false"
                                            OnClientClick="return confirm('Delete this course?');" />

                                    </ItemTemplate>
                                </asp:TemplateField>

                            </Columns>

                        </asp:GridView>

                    </div>

                </section>
            </div>

            <!-- COURSE & INSTRUCTOR -->
            <div id="pane-instructors"
                class="tab-pane"
                role="tabpanel"
                hidden="hidden">

                <div id="course-editor">

                    <section class="panel">

                        <div class="panel-head">
                            <div>
                                <h2>Course Editor &amp; Instructor</h2>
                                <p class="muted">
                                    Create or edit a course and assign its instructor.
                                </p>
                            </div>
                        </div>

                        <div class="panel-body">

                            <asp:HiddenField
                                ID="hfCourseID"
                                runat="server"
                                Value="0" />

                            <div class="form-group">
                                <label class="form-label">
                                    Course Title
                                </label>

                                <asp:TextBox
                                    ID="txtCourseTitle"
                                    runat="server"
                                    CssClass="form-control"
                                    MaxLength="50" />
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Course Description
                                </label>

                                <asp:TextBox
                                    ID="txtDescription"
                                    runat="server"
                                    CssClass="form-control"
                                    TextMode="MultiLine"
                                    Rows="4" />
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Announcement
                                </label>

                                <asp:TextBox
                                    ID="txtAnnouncement"
                                    runat="server"
                                    CssClass="form-control"
                                    TextMode="MultiLine"
                                    Rows="3" />
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Assigned Instructor
                                </label>

                                <asp:DropDownList
                                    ID="ddlInstructor"
                                    runat="server"
                                    CssClass="form-control" />
                            </div>

                            <div class="form-grid">

                                <div class="form-group">
                                    <label class="form-label">
                                        Program
                                    </label>

                                    
                                <asp:DropDownList
                                    ID="ddlProgram"
                                    runat="server"
                                    CssClass="form-control"
                                    EnableViewState="true"
                                    AppendDataBoundItems="false" />

                                </div>

                                <div class="form-group">
                                    <label class="form-label">
                                        Year Level
                                    </label>

                                    <asp:DropDownList
                                        ID="ddlYearLevel"
                                        runat="server"
                                        CssClass="form-control">

                                        <asp:ListItem
                                            Text="-- Select Year Level --"
                                            Value="" />

                                        <asp:ListItem
                                            Text="1st Year"
                                            Value="1" />

                                        <asp:ListItem
                                            Text="2nd Year"
                                            Value="2" />

                                        <asp:ListItem
                                            Text="3rd Year"
                                            Value="3" />

                                        <asp:ListItem
                                            Text="4th Year"
                                            Value="4" />

                                    </asp:DropDownList>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">
                                        Semester
                                    </label>

                                    <asp:DropDownList
                                        ID="ddlSemester"
                                        runat="server"
                                        CssClass="form-control">

                                        <asp:ListItem
                                            Text="-- Select Semester --"
                                            Value="" />

                                        <asp:ListItem
                                            Text="1st Semester"
                                            Value="1" />

                                        <asp:ListItem
                                            Text="2nd Semester"
                                            Value="2" />

                                    </asp:DropDownList>
                                </div>

                            </div>

                            <div class="checkbox-line">
                                <asp:CheckBox
                                    ID="chkPublished"
                                    runat="server"
                                    Text=" Publish course" />
                            </div>

                            <div class="button-row">

                                <asp:Button
                                    ID="btnSaveCourse"
                                    runat="server"
                                    Text="Save Course"
                                    CssClass="btn btn-primary"
                                    OnClick="btnSaveCourse_Click"
                                    CausesValidation="false" />

                                <asp:Button
                                    ID="btnClear"
                                    runat="server"
                                    Text="Clear"
                                    CssClass="btn btn-secondary"
                                    OnClick="btnClear_Click"
                                    CausesValidation="false" />

                            </div>

                        </div>
                    </section>
                </div>
            </div>

            <!-- ASSIGN STUDENTS: course-first, approved and active students -->
            <div id="pane-students" class="tab-pane" role="tabpanel" hidden="hidden">
                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h2>Assign Students to a Course</h2>
                            <p class="muted">Choose a course first. Approved, active students from any program or year level can be assigned.</p>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="assignment-filter-grid">
                            <div><label class="form-label" for="<%= ddlAssignProgram.ClientID %>">1. Program</label>
                                <asp:DropDownList ID="ddlAssignProgram" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="AssignmentFilter_Changed" /></div>
                            <div><label class="form-label" for="<%= ddlAssignYear.ClientID %>">2. Year Level</label>
                                <asp:DropDownList ID="ddlAssignYear" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="AssignmentFilter_Changed">
                                    <asp:ListItem Value="">All year levels</asp:ListItem>
                                    <asp:ListItem Value="1">1st Year</asp:ListItem><asp:ListItem Value="2">2nd Year</asp:ListItem>
                                    <asp:ListItem Value="3">3rd Year</asp:ListItem><asp:ListItem Value="4">4th Year</asp:ListItem>
                                </asp:DropDownList></div>
                            <div><label class="form-label" for="<%= ddlAssignSemester.ClientID %>">Semester (optional filter)</label>
                                <asp:DropDownList ID="ddlAssignSemester" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="AssignmentFilter_Changed">
                                    <asp:ListItem Value="">All semesters</asp:ListItem>
                                    <asp:ListItem Value="1">1st Semester</asp:ListItem><asp:ListItem Value="2">2nd Semester</asp:ListItem>
                                </asp:DropDownList></div>
                        </div>
                        <div class="assignment-course-picker">
                            <label class="form-label" for="<%= ddlEnrollmentCourse.ClientID %>">3. Select a course</label>
                            <asp:DropDownList ID="ddlEnrollmentCourse" runat="server"
                                CssClass="form-control" AutoPostBack="true"
                                OnSelectedIndexChanged="ddlEnrollmentCourse_SelectedIndexChanged" />
                        </div>
                        <div class="assignment-list-heading">
                            <div>
                                <h3>4. Select eligible students</h3>
                                <p class="hint">Approved, active students from any program and year level are available.</p>
                            </div>
                            <span class="assignment-count" id="selectedStudentCount">0 selected</span>
                        </div>
                        <div class="assignment-toolbar">
                            <input id="assignmentStudentSearch" type="search" class="form-control"
                                placeholder="Search student name or email..." oninput="filterEligibleStudents()" />
                            <button type="button" class="btn btn-secondary" onclick="toggleVisibleStudents(true)">Select visible</button>
                            <button type="button" class="btn btn-secondary" onclick="toggleVisibleStudents(false)">Clear visible</button>
                        </div>
                        <div class="eligible-student-list" id="eligibleStudentList">
                            <asp:CheckBoxList ID="cblEligibleStudents" runat="server"
                                RepeatLayout="Flow" RepeatDirection="Vertical"
                                CssClass="eligible-checkbox-list" />
                        </div>
                        <asp:Label ID="lblEligibleInfo" runat="server" CssClass="hint" />
                        <div class="assignment-footer">
                            <div>
                                <strong id="assignmentPreview">0 students selected</strong>
                                <p class="hint">Already-assigned students will not be assigned again.</p>
                            </div>
                            <asp:Button ID="btnEnroll" runat="server" Text="Assign Selected Students"
                                CssClass="btn btn-primary" CausesValidation="false"
                                OnClick="btnEnroll_Click" OnClientClick="return confirmStudentAssignments();" />
                        </div>
                    </div>
                </section>
                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h2>Currently Assigned Students</h2>
                            <p class="muted">Assignments for the selected course. Remove students individually when needed.</p>
                        </div>
                    </div>
                    <div class="table-wrap">
                        <asp:GridView ID="gvEnrolledStudents" runat="server"
                            AutoGenerateColumns="False" CssClass="data-table" GridLines="None"
                            EmptyDataText="No students assigned to this course."
                            OnRowCommand="gvEnrolledStudents_RowCommand">
                            <Columns>
                                <asp:BoundField DataField="StudentID" HeaderText="Student ID" />
                                <asp:BoundField DataField="StudentName" HeaderText="Student Name" />
                                <asp:BoundField DataField="Email" HeaderText="Email" />
                                <asp:BoundField DataField="Status" HeaderText="Status" />
                                <asp:TemplateField HeaderText="Action"><ItemTemplate>
                                    <asp:LinkButton ID="btnRemoveStudent" runat="server" Text="Remove"
                                        CssClass="table-action danger" CommandName="RemoveStudent"
                                        CommandArgument='<%# Eval("CourseStudentID") %>' CausesValidation="false"
                                        OnClientClick="return confirm('Remove this student from the course?');" />
                                </ItemTemplate></asp:TemplateField>
                            </Columns>
                        </asp:GridView>
                    </div>
                </section>
            </div>

        </main>

    </form>

    <script type="text/javascript">
        (function () {
            var storageKey = "MiniLMS.ManageCourses.activeTab";

            function setTab(name) {
                if (name !== "courses" &&
                    name !== "instructors" &&
                    name !== "students") {
                    name = "courses";
                }

                var buttons =
                    document.querySelectorAll(".tab-button");

                for (var i = 0; i < buttons.length; i++) {
                    var active =
                        buttons[i].getAttribute("data-tab") === name;

                    buttons[i].classList.toggle("active", active);
                    buttons[i].setAttribute(
                        "aria-selected",
                        active ? "true" : "false"
                    );
                }

                var panes =
                    document.querySelectorAll(".tab-pane");

                for (var j = 0; j < panes.length; j++) {
                    var show =
                        panes[j].id === "pane-" + name;

                    panes[j].hidden = !show;
                    panes[j].classList.toggle("active", show);
                }

                try {
                    sessionStorage.setItem(storageKey, name);
                } catch (e) { }
            }

            document.addEventListener(
                "DOMContentLoaded",
                function () {

                    var initial = "courses";

                    try {
                        initial =
                            sessionStorage.getItem(storageKey)
                            || "courses";
                    } catch (e) { }

                    setTab(initial);

                    var tabButtons =
                        document.querySelectorAll("[data-tab]");

                    for (var i = 0; i < tabButtons.length; i++) {
                        tabButtons[i].addEventListener(
                            "click",
                            function () {
                                setTab(
                                    this.getAttribute("data-tab")
                                );
                            }
                        );
                    }

                    var openButtons =
                        document.querySelectorAll("[data-open-tab]");

                    for (var j = 0; j < openButtons.length; j++) {
                        openButtons[j].addEventListener(
                            "click",
                            function () {
                                setTab(
                                    this.getAttribute("data-open-tab")
                                );
                            }
                        );
                    }

                    document.addEventListener(
                        "click",
                        function (event) {
                            var target = event.target;

                            if (target.closest('[id$="btnEdit"]')) {
                                try {
                                    sessionStorage.setItem(
                                        storageKey,
                                        "instructors"
                                    );
                                } catch (e) { }
                            }

                            if (target.closest('[id$="btnSelect"]')) {
                                try {
                                    sessionStorage.setItem(
                                        storageKey,
                                        "students"
                                    );
                                } catch (e) { }
                            }
                        }
                    );
                }
            );
        })();
    </script>


    <style>
        .assignment-filter-grid { display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:18px; }
        @media(max-width:760px){.assignment-filter-grid{grid-template-columns:1fr;}}
    </style>
    <script type="text/javascript">
        function eligibleBoxes() {
            return Array.prototype.slice.call(document.querySelectorAll('#eligibleStudentList input[type="checkbox"]'));
        }
        function updateStudentPreview() {
            var count = eligibleBoxes().filter(function (x) { return x.checked; }).length;
            document.getElementById('selectedStudentCount').textContent = count + ' selected';
            document.getElementById('assignmentPreview').textContent = count + ' students selected';
        }
        function filterEligibleStudents() {
            var query = document.getElementById('assignmentStudentSearch').value.toLowerCase().trim();
            eligibleBoxes().forEach(function (box) {
                var row = box.closest('span');
                if (row) row.style.display = row.textContent.toLowerCase().indexOf(query) >= 0 ? '' : 'none';
            });
        }
        function toggleVisibleStudents(checked) {
            eligibleBoxes().forEach(function (box) {
                var row = box.closest('span');
                if (row && row.style.display !== 'none') box.checked = checked;
            });
            updateStudentPreview();
        }
        function confirmStudentAssignments() {
            var count = eligibleBoxes().filter(function (x) { return x.checked; }).length;
            if (!count) { alert('Select at least one eligible student.'); return false; }
            return confirm('Assign ' + count + ' selected student(s) to this course?');
        }
        document.addEventListener('DOMContentLoaded', function () {
            var list = document.getElementById('eligibleStudentList');
            if (list) list.addEventListener('change', updateStudentPreview);
            updateStudentPreview();
        });
    </script>


    <script type="text/javascript">
      function filterCoursesByProgram() {
        var table = document.getElementById('<%= gvCourses.ClientID %>');
        var filter = document.getElementById('<%= ddlAllCoursesProgram.ClientID %>');
        if (!table || !filter) return;
        var rows = table.querySelectorAll('tr');
        var visible = 0;
        for (var i=1; i<rows.length; i++) {
          var cells = rows[i].querySelectorAll('td');
          if (!cells.length) continue;
          // Columns: CourseID, Program, Year, Semester, Course...
          var program = cells.length > 1 ? cells[1].textContent.trim() : '';
          var show = !filter.value || program === filter.value;
          rows[i].style.display = show ? '' : 'none';
          if (show) visible++;
        }
        var count = document.getElementById('courseProgramCount');
        if (count) count.textContent = visible + ' course(s) displayed';
      }
      document.addEventListener('DOMContentLoaded', function() {
        var table = document.getElementById('<%= gvCourses.ClientID %>');
          var filter = document.getElementById('<%= ddlAllCoursesProgram.ClientID %>');
          if (!table || !filter) return;
          filterCoursesByProgram();
      });
    </script>
</body>
</html>
